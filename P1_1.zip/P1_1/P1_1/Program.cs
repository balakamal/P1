﻿using System;

namespace P1_1
{
    class Program
    {
        static void Main(string[] args)
        {
            byte[] bmpBytes = new byte[] {
        0x42,0x4D,0x4C,0x00,0x00,0x00,0x00,0x00,
        0x00,0x00,0x1A,0x00,0x00,0x00,0x0C,0x00,
        0x00,0x00,0x04,0x00,0x04,0x00,0x01,0x00,
        0x18,0x00,0x00,0x00,0xFF,0xFF,0xFF,0xFF,
        0x00,0x00,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
        0xFF,0x00,0x00,0x00,0xFF,0xFF,0xFF,0x00,
        0x00,0x00,0xFF,0x00,0x00,0xFF,0xFF,0xFF,
        0xFF,0x00,0x00,0xFF,0xFF,0xFF,0xFF,0xFF,
        0xFF,0x00,0x00,0x00,0xFF,0xFF,0xFF,0x00,
        0x00,0x00
        };

            byte[] input = new byte[16];

            int j = 0;
            var arg = "";
            if (args.Length > 0)
            {
                arg = args[0];
            }
            else
            {
                arg = "B1 FF FF CC 98 80 09 EA 04 48 7E C9";
            }
            String[] ip = arg.Split(" ");
            foreach (String byt in ip)
            {
                input[j++] = Convert.ToByte(byt, 16);
            }

            int iC = 0;
            for (int i = 26; i < bmpBytes.Length; i = i + 4)
            {

                byte b = input[iC++];

                byte b1 = Convert.ToByte((b >> 6) & 3);

                byte b2 = Convert.ToByte((b >> 4) & 3);

                byte b3 = Convert.ToByte((b >> 2) & 3);

                byte b4 = Convert.ToByte((b >> 0) & 3);

                bmpBytes[i] = (byte)(bmpBytes[i] ^ b1);
                bmpBytes[i + 1] = (byte)(bmpBytes[i + 1] ^ b2);
                bmpBytes[i + 2] = (byte)(bmpBytes[i + 2] ^ b3);
                bmpBytes[i + 3] = (byte)(bmpBytes[i + 3] ^ b4);

            }

            Console.WriteLine(BitConverter.ToString(bmpBytes).Replace("-", " "));
        }
    }
}
