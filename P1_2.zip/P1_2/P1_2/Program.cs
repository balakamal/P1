﻿using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;
namespace P1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string plain = args[0];
            string cipher = args[1];

            DateTime startDate = new DateTime(2020, 07, 03, 11, 00, 00);

            int i = 1;
            while (i < 1440)
            {
                startDate = startDate.AddMinutes(1);
                TimeSpan ts = startDate.Subtract(new DateTime(1970, 1, 1));
                Random rng = new Random((int)ts.TotalMinutes);
                byte[] key = BitConverter.GetBytes(rng.NextDouble());
                string enc = Encrypt(key, plain);
                if (cipher.Equals(enc))
                {
                    Console.WriteLine((int)ts.TotalMinutes);
                }
                i++;
            }

        }

        static string Encrypt(byte[] key, string secretString)
        {
            DESCryptoServiceProvider csp = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, csp.CreateEncryptor(key, key), CryptoStreamMode.Write);
            StreamWriter sw = new StreamWriter(cs);
            sw.Write(secretString);
            sw.Flush();
            cs.FlushFinalBlock();
            sw.Flush();
            return Convert.ToBase64String(ms.GetBuffer(), 0, (int)ms.Length);
        }
        
    }
}
